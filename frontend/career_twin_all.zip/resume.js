
function analyzeResume(){

    let file =
    document.getElementById("resumeFile").value;

    if(file==""){
        alert("Please upload a resume first");
        return;
    }

    document.getElementById("result").style.display="block";
}